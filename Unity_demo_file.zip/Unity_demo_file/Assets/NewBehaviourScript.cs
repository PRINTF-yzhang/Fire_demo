﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{

    public int TranslateSpeed = 30;
    public int RotateSpeed = 1000;

    void OnGUI()
    {

        GUI.backgroundColor = Color.red;

        if (GUI.Button(new Rect(10, 10, 100, 50), "Rotate to Left"))
        {
   
            transform.Rotate(Vector3.up * Time.deltaTime * (-RotateSpeed));

        }
        if (GUI.Button(new Rect(120, 10, 100, 50), "Move Forward"))
        {
    
            transform.Translate(Vector3.forward * Time.deltaTime * TranslateSpeed);
 
        }
        if (GUI.Button(new Rect(230, 10, 100, 50), "Rotate to Right"))
        {
   
            transform.Rotate(Vector3.up * Time.deltaTime * RotateSpeed);
        }
        if (GUI.Button(new Rect(120, 70, 100, 50), "Move Backward"))
        {
   
            transform.Translate(Vector3.forward * Time.deltaTime * (-TranslateSpeed));
        }
        if (GUI.Button(new Rect(10, 70, 100, 50), "Move to Left"))
        {
      
            transform.Translate(Vector3.right * Time.deltaTime * (-TranslateSpeed));
    
        }
        if (GUI.Button(new Rect(230, 70, 100, 50), "Move to Right"))
        {
     
            transform.Translate(Vector3.right * Time.deltaTime * TranslateSpeed);
        }

        GUI.Label(new Rect(340, 10, 250, 50), "Fire Position" + transform.position);
   
        GUI.Label(new Rect(340, 70, 250, 50), "Fire Rotation" + transform.rotation);
    }
}
