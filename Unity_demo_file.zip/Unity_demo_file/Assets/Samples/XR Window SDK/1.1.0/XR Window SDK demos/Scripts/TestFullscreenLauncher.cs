﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System.Collections.Generic;

namespace XR.Samples
{
    public class TestFullscreenLauncher : TestLauncher
    {
        public XRWindowFullscreen window;
        private HashSet<string> appSet = new HashSet<string>();

        protected override void Start()
        {
            if (XRManager.Initialized)
            {
                AppManager.OnAppStatus += AppManager_OnAppStatus;
                OnOpenApp += TestFullscreenLauncher_OnOpenApp;
            }
            base.Start();
        }

        protected override void OnDestroy()
        {
            if (XRManager.Initialized)
            {
                AppManager.OnAppStatus -= AppManager_OnAppStatus;
                OnOpenApp -= TestFullscreenLauncher_OnOpenApp;
            }
            base.OnDestroy();
        }

        private void TestFullscreenLauncher_OnOpenApp()
        {
            window.WindowFullscreen = false;
        }

        private void AppManager_OnAppStatus(string packageName, XRAppStatus status)
        {
            if (status == XRAppStatus.XR_APP_STATUS_OPENED)
            {
                appSet.Add(packageName);
            }
            else if (status == XRAppStatus.XR_APP_STATUS_CLOSED)
            {
                appSet.Remove(packageName);
            }
            //无应用开启时全屏
            if (appSet.Count == 0)
            {
                window.WindowFullscreen = true;
            }
        }


    }
}