﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System.Text;
using UnityEngine;
using TMPro;

namespace XR.Samples
{
    public class TestUtilities : MonoBehaviour
    {
        public TMP_Text text;

        public void TestAudio()
        {
            if (XRManager.Initialized && text != null)
            {
                int level = -1, maxLevel = -1;
                AudioManager.GetStreamVolume(XRAudioStream.XR_AUDIO_STREAM_MUSIC, ref level);
                AudioManager.GetStreamMaxVolume(XRAudioStream.XR_AUDIO_STREAM_MUSIC, ref maxLevel);
                var content = string.Format("Testing AudioManager\nCurrent Mode: {0}\nLevel: {1}\nMax Level: {2}", AudioManager.RingerMode, level, maxLevel);
                text.text = content;
            }
        }


        public void TestBattery()
        {
            if (XRManager.Initialized && text != null)
            {
                var content = string.Format("Testing BatteryManager\nLevel: {0}\n", BatteryManager.Level);
                text.text = content;
            }
        }

        public void TestNetwork()
        {
            if (XRManager.Initialized && text != null)
            {
                var type = NetworkManager.NetworkType;
                string content;
                content = string.Format("NetworkType: {0}", type);
                if (type == XRConnectivityNetworkType.XR_CONNECTIVITY_NETWORK_WIFI)
                {

                    var wifiInfo = NetworkManager.WifiInfo;

                    if (wifiInfo != null)
                    {
                        content += string.Format("\nWifi SSID: {0}\nWifi Level: {1}", type, wifiInfo.SSID, wifiInfo.SignalLevel);
                    }
                    else
                    {
                        content += string.Format("\nGet Wifi info failed");
                    }
                }
                text.text = content;
            }
        }

        public void TestPackage()
        {
            if (XRManager.Initialized && text != null)
            {
                var list = PackageManager.GetPackageList();
                string content;
                if (list != null)
                {
                    StringBuilder builder = new StringBuilder();
                    builder.AppendLine("Testing PackageManager");
                    builder.AppendFormat("Get package list: {0}\n", list.Count);
                    for (int i = 0; i < list.Count; ++i)
                    {
                        builder.AppendFormat("{0}. {1}\n", i + 1, list[i].Name);
                    }
                    content = builder.ToString();
                }
                else
                {
                    content = string.Format("Testing PackageManager\nGet package list failed");
                }
                text.text = content;
            }
        }

        public void TestInputDevice()
        {
            if (XRManager.Initialized && text != null)
            {
                var list = InputDevice.GetInputDeviceList();
                string content;
                if (list != null)
                {
                    StringBuilder builder = new StringBuilder();
                    builder.AppendLine("Testing InputDevice");
                    builder.AppendFormat("Get InputDevice list: {0}\n", list.Length);
                    for (int i = 0; i < list.Length; ++i)
                    {
                        builder.AppendLine($"{i + 1}. [{list[i].DeviceId}]{list[i].Name}({list[i].Width}x{list[i].Height}) follow:{list[i].Follow}, offset:{list[i].Offset}\n");
                    }
                    content = builder.ToString();
                }
                else
                {
                    content = string.Format("Testing PackageManager\nGet package list failed");
                }
                text.text = content;
            }
        }

        public void TestOther()
        {
            if (XRManager.Initialized && text != null)
            {
                text.text = string.Format("Testing Locale\nLanguage: {0}\n", Locale.Language);
            }
        }

        private void Awake()
        {
            if (XRManager.Initialized)
            {
                InputDevice.OnInputDeviceEvent += InputDevice_OnInputDeviceEvent;
                Locale.OnLanguageChange += Locale_OnLanguageChange;
                PackageManager.OnPackageEvent += PackageManager_OnPackageEvent;
                NetworkManager.OnConnectivity += NetworkManager_OnConnectivity;
                NetworkManager.OnWifiConnection += NetworkManager_OnWifiConnection;
                NetworkManager.OnWifiSignalLevel += NetworkManager_OnWifiSignalLevel;
                BatteryManager.OnBatteryLevel += BatteryManager_OnBatteryLevel;
                AudioManager.OnAudioVolume += AudioManager_OnAudioVolume;
            }
        }

        private void OnDestroy()
        {
            if (XRManager.Initialized)
            {
                InputDevice.OnInputDeviceEvent -= InputDevice_OnInputDeviceEvent;
                Locale.OnLanguageChange -= Locale_OnLanguageChange;
                PackageManager.OnPackageEvent -= PackageManager_OnPackageEvent;
                NetworkManager.OnConnectivity -= NetworkManager_OnConnectivity;
                NetworkManager.OnWifiConnection -= NetworkManager_OnWifiConnection;
                NetworkManager.OnWifiSignalLevel -= NetworkManager_OnWifiSignalLevel;
                BatteryManager.OnBatteryLevel -= BatteryManager_OnBatteryLevel;
                AudioManager.OnAudioVolume -= AudioManager_OnAudioVolume;
            }
        }

        private void AudioManager_OnAudioVolume(XRAudioStream audioStream, int volume)
        {
            Debug.LogFormat("AudioManager_OnAudioVolume: {0}, {1}", audioStream, volume);
        }

        private void BatteryManager_OnBatteryLevel(int level)
        {
            Debug.LogFormat("BatteryManager_OnBatteryLevel: {0}", level);
        }

        private void NetworkManager_OnWifiSignalLevel(WifiInfo wifiInfo, int level)
        {
            Debug.LogFormat("NetworkManager_OnWifiSignalLevel: {0}, {1}", wifiInfo.SSID, level);
        }

        private void NetworkManager_OnWifiConnection(WifiInfo wifiInfo)
        {
            Debug.LogFormat("NetworkManager_OnWifiConnection: {0}", wifiInfo.SSID);
        }

        private void NetworkManager_OnConnectivity(XRConnectivityEvent eventType, XRConnectivityNetworkType networkType)
        {
            Debug.LogFormat("NetworkManager_OnConnectivity: {0}, {1}", eventType, networkType);
        }

        private void PackageManager_OnPackageEvent(XRPackageEvent type, Package package)
        {
            Debug.LogFormat("PackageManager_OnPackageEvent: {0}, {1}", type, package);
        }

        private void Locale_OnLanguageChange(string language)
        {
            Debug.LogFormat("Locale_OnLanguageChange: {0}", language);
        }

        private void InputDevice_OnInputDeviceEvent(XRInputDeviceEvent ev, InputDevice device)
        {
            Debug.LogFormat("InputDevice_OnInputDeviceEvent: {0} {1}", ev, device.Name);
        }

    }
}