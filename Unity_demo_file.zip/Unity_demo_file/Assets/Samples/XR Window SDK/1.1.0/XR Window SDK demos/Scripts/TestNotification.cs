﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using UnityEngine;
using System.IO;

namespace XR.Samples
{
    public class TestNotification : MonoBehaviour
    {
        private Notification notification = null;
        private void Awake()
        {
            if (XRManager.Initialized)
            {
                Notification.OnNotification += Notification_OnNotification;
            }
        }

        private void Notification_OnNotification(string ownerPackageName, XRNotificationEventType type, Notification notification)
        {
            if (notification != null)
            {
                Debug.LogFormat("Notification received. Package:{0}, Type:{1}, ID:{2}", ownerPackageName, type, notification.NotifyId);
            }
            else
            {
                Debug.LogFormat("Notification received. Package:{0}, Type:{1}", ownerPackageName, type);
            }

        }

        public void Notify()
        {
            if (!XRManager.Initialized)
            {
                return;
            }
            notification = new Notification();
            string iconDir = "/sdcard/iris/icons_raw";
            if (!Directory.Exists(iconDir))
            {
                Debug.LogError($"{iconDir} does not exist, need another directory.");
                return;
            }
            var files = Directory.GetFiles(iconDir, "*.png");
            if (files == null || files.Length == 0)
            {
                Debug.LogError($"Found no files in {iconDir}, need another directory.");
                return;
            }
            notification.Icon = new Bitmap(files[0]);
            notification.NotifyId = 123;
            notification.Title = "Unity Notification Test";
            notification.Subtitle = "Test";
            notification.Text = "This is a notification";
            notification.BriefText = "Notification";
            notification.Category = XRNotificationCategory.XR_NOTIFICATION_CATEGORY_MESSAGE;
            notification.DisplayStyle = XRNotificationDisplayStyle.XR_NOTIFICATION_DISPLAY_STYLE_FLOAT;
            notification.Notify();
        }
        public void Cancel()
        {
            if (notification != null)
            {
                notification.Cancel();
            }
        }
    }
}