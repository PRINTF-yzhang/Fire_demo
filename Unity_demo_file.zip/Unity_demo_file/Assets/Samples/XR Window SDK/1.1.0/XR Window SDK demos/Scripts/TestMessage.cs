﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System.Collections.Generic;
using UnityEngine;

namespace XR.Samples
{
    public class TestMessage : MonoBehaviour
    {
        public string leftPath, rightPath;
        enum CompositorChannelAction
        {
            LAUNCHER_VISIBLE = 0,
            LAUNCHER_HIDE,          //1
            LAYOUT_ENABLE,          //2
            LAYOUT_DISABLE,         //3
            WINDOW_MODE,            //4
            OBJECT_MODE,            //5
            CLEAN_APPS,             //6
            MSGBOX_VISIBLE,         //7
            MSGBOX_HIDE,            //8
            REBOOT,                 //9
            SHUTDOWN,               //10
            RESET_YAW,              //11
            SET_FOLLOWPOSE,         //12
            CONSOLE_MODE,           //13
            SYSTEM_REBOOT,          //14 
            SYSTEM_SHUTDOWN,        //15  
            REQUEST_INSTRUCTION,    //16
            MODIFY_CURSOR_STATE,    //17
            MENU_VISIBLE,           //18
            MENU_HIDE,              //19
            START_WINDOW_FOLLOW,    //20
            STOP_WINDOW_FOLLOW,     //21
            CANCEL_EDITS,           //22
            CHANGE_BACKGROUND       //23
        };
        public List<string> channels = new List<string>() { "compositor" };
        // Use this for initialization
        void Start()
        {
            if (XRManager.Initialized)
            {
                foreach (var channel in channels)
                {
                    AppManager.JoinChannel(channel);
                }
            }
        }
        public void ChangeBackground()
        {
            Message message = new Message();
            message.SetChannel("compositor");
            message.SetValue("button", (int)CompositorChannelAction.CHANGE_BACKGROUND);
            message.SetValue("leftPath", leftPath);
            message.SetValue("rightPath", rightPath);
            AppManager.BroadcastMessage(message);
        }
    }
}