﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System;
using System.Runtime.InteropServices;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;

namespace XR.Samples
{
    public class LibYuv
    {
        [DllImport("yuv", CharSet = CharSet.Ansi)]
        public extern static int NV21ToRGB24(IntPtr src_y, int src_stride_y, IntPtr src_vu, int src_stride_vu, IntPtr dst_rgb24, int dst_stride_rgb24, int width, int height);

        public static int Convert(Texture2D texture, int width, int height, IntPtr src)
        {
            var buffer = texture.GetRawTextureData<byte>();
            int error = 0;
            unsafe
            {
                error = NV21ToRGB24(src, width, src + width * height, width, new IntPtr(buffer.GetUnsafePtr()), width * 3, width, -height);
            }
            texture.Apply();
            return error;
        }
    }
}