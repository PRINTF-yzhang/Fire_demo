﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System.Text;
using UnityEngine;

namespace XR.Samples
{
    public class TestSlam : MonoBehaviour
    {
        public void TestHandTrackingMesh()
        {
            XRVector3i[] leftIndices = new XRVector3i[0], rightIndices = new XRVector3i[0];
            XRDebug.ErrorAssert(Slam.GetHandTrackingMeshIndices(ref leftIndices, ref rightIndices));
            XRVector3f[] leftVertices = new XRVector3f[0], rightVertices = new XRVector3f[0];
            bool leftDetected = false, rightDeteced = false;
            XRDebug.ErrorAssert(Slam.GetHandTrackingMeshVertices(ref leftVertices, ref leftDetected, ref rightVertices, ref rightDeteced));
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("HandTrackinMesh:");
            builder.AppendLine("------------------Left hand-------------------");
            PrintHandTrackinMesh(builder, leftVertices, leftIndices);
            builder.AppendLine("------------------Right hand-------------------");
            PrintHandTrackinMesh(builder, rightVertices, rightIndices);
            Debug.Log(builder.ToString());
        }
        public void TestHandTracking()
        {

            XRHandTrackingInfoWithOrientation info = new XRHandTrackingInfoWithOrientation();
            XRDebug.ErrorAssert(Slam.StartHandTracking());
            var error = Slam.GetHandTrackingInfoWithOrientation(ref info);
            XRDebug.ErrorAssert(error);
            if (error == 0)
            {
                PrintHandTrackinInfo(ref info);
            }
            XRDebug.ErrorAssert(Slam.PauseHandTracking());
            XRDebug.ErrorAssert(Slam.ResumeHandTracking());
            error = Slam.GetHandTrackingInfoWithOrientation(ref info);
            XRDebug.ErrorAssert(error);
            if (error == 0)
            {
                PrintHandTrackinInfo(ref info);
            }
            XRDebug.ErrorAssert(Slam.StopHandTracking());
        }

        public void TestPlaneDetection()
        {
            XRPlaneInfo[] infos;
            XRDebug.ErrorAssert(Slam.StartPlaneDetection());
            var error = Slam.GetPlaneInfos(out infos);
            XRDebug.ErrorAssert(error);
            if (error == 0)
            {
                PrintPlaneInfo(infos);
            }
            XRDebug.ErrorAssert(Slam.PausePlaneDetection());
            XRDebug.ErrorAssert(Slam.ResumePlaneDetection());
            error = Slam.GetPlaneInfos(out infos);
            XRDebug.ErrorAssert(error);
            if (error == 0)
            {
                PrintPlaneInfo(infos);
            }
            XRDebug.ErrorAssert(Slam.StopPlaneDetection());
        }

        public void TestReconstruction()
        {
            SlamMesh[] meshes;
            XRDebug.ErrorAssert(Slam.StartReconstruction());
            var error = Slam.GetMeshList(out meshes);
            XRDebug.ErrorAssert(error);
            if (error == 0)
            {
                PrintMeshInfo(meshes);
            }
            XRDebug.ErrorAssert(Slam.PauseReconstruction());
            XRDebug.ErrorAssert(Slam.ResumeReconstruction());
            error = Slam.GetMeshList(out meshes);
            XRDebug.ErrorAssert(error);
            if (error == 0)
            {
                PrintMeshInfo(meshes);
            }
            XRDebug.ErrorAssert(Slam.StopReconstruction());
        }

        public void TestSensor()
        {
            ulong predictTime = 11 * 1000000;
            ulong timestamp = 0;
            XRPose pose = new XRPose();
            XRDebug.ErrorAssert(Slam.GetSensorPose(predictTime, ref pose, ref timestamp));
            Debug.LogFormat("GetSensorPose predict:{0} timestamp:{1} pose:{2}", predictTime, timestamp, pose);
        }
        void PrintHandTrackinMesh(StringBuilder builder, XRVector3f[] vertices, XRVector3i[] indices)
        {
            builder.Append("vertices: ");
            foreach (var v in vertices)
            {
                builder.Append(v.ToString());
            }
            builder.AppendLine();
            builder.Append("indices: ");
            foreach (var v in indices)
            {
                builder.Append(v.ToString());
            }
            builder.AppendLine();
        }
        void PrintHandTrackinInfo(ref XRHandTrackingInfoWithOrientation info)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("HandTrackinInfo:");
            builder.AppendLine("------------------Left hand-------------------");
            PrintSingleHandTrackinInfo(builder, ref info.left);
            builder.AppendLine("------------------Right hand------------------");
            PrintSingleHandTrackinInfo(builder, ref info.right);
            builder.AppendLine("----------------------------------------------");
            Debug.Log(builder.ToString());
        }
        void PrintSingleHandTrackinInfo(StringBuilder builder, ref XRSingleHandTrackingInfoWithOrientation info)
        {
            builder.AppendLine(string.Format("Hand detected: {0}", info.handDetected));
            if (!info.handDetected)
            {
                return;
            }
            builder.AppendLine(string.Format("confScore: {0}", info.confScore));

            builder.AppendLine(string.Format("handGestureStatic: {0}", info.handGestureStatic));

            builder.AppendLine(string.Format("handGestureDynamic: {0}", info.handGestureDynamic));

            builder.AppendLine(string.Format("handGestureConfScore: {0}", info.handGestureConfScore));

            builder.Append("pred2D: ");
            foreach (var p2d in info.pred2D)
            {
                builder.Append(p2d.ToString());
            }
            builder.AppendLine();

            builder.Append("pred3D: ");
            foreach (var p3d in info.pred3D)
            {
                builder.Append(p3d.ToString());
            }
            builder.AppendLine();

            builder.Append("projected2D: ");
            foreach (var proj2d in info.projected2D)
            {
                builder.Append(proj2d.ToString());
            }
            builder.AppendLine();

            builder.AppendLine(string.Format("handOrientation: {0}", info.handOrientation));

            builder.AppendLine(string.Format("handOrientationVector: {0}", info.handOrientationVector));

            builder.Append("fingerOrientation: ");
            foreach (var orientation in info.fingerOrientation)
            {
                builder.Append(orientation.ToString());
                builder.Append(", ");
            }
            builder.AppendLine();
            builder.Append("fingerOrientationVector: ");
            foreach (var orientationV in info.fingerOrientationVector)
            {
                builder.Append(orientationV.ToString());
            }
            builder.AppendLine();

            builder.AppendLine(string.Format("boundingBox: xMin:{0}, yMin:{1}, xMax:{2}, yMax:{3}",
                info.boundingBox.xMin, info.boundingBox.yMin, info.boundingBox.xMax, info.boundingBox.yMax));
        }

        void PrintPlaneInfo(XRPlaneInfo[] infos)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine(string.Format("PlaneInfo count {0}:", infos.Length));
            for (int i = 0; i < infos.Length; ++i)
            {
                builder.AppendLine(string.Format("Plane-{0} position:{1}, normal:{2}, forward:{3}, size:{4}",
                    i, infos[i].position, infos[i].normal, infos[i].forward, infos[i].size));
            }
            Debug.Log(builder.ToString());
        }

        void PrintMeshInfo(SlamMesh[] meshes)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine(string.Format("Mesh count {0}:", meshes.Length));
            for (int i = 0; i < meshes.Length; ++i)
            {
                builder.AppendFormat("Mesh-{0}: ", i);
                foreach (var point in meshes[i].MeshPoints)
                {
                    builder.AppendFormat("[position:{0} normal:{1}]", point.position, point.normal);
                }
                builder.AppendLine();
            }
            Debug.Log(builder.ToString());
        }
    }
}