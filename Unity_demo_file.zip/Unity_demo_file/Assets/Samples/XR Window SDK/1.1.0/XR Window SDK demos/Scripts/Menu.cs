﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using UnityEngine;
using UnityEngine.SceneManagement;

namespace XR.Samples
{
    public class Menu : MonoBehaviour
    {
        public GameObject backButton;
        public GameObject model;
        public void LoadScene(string sceneName)
        {
            SceneManager.LoadScene(sceneName);
            var isMain = sceneName == "Main";
            gameObject.SetActive(isMain);
            backButton.SetActive(!isMain);
            model.SetActive(isMain);
        }
    }
}