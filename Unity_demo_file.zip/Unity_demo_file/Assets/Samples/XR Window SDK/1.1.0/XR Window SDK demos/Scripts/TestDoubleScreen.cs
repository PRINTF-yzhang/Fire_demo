﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

using System;
using System.Collections.Generic;
using UnityEngine;

namespace XR.Samples
{
    public class TestDoubleScreen : MonoBehaviour
    {
        public List<MeshRenderer> renders;
        public void ChangeColor()
        {
            if (renders != null)
            {
                foreach (var renderer in renders)
                {
                    renderer.material.color = new Color(UnityEngine.Random.value, UnityEngine.Random.value, UnityEngine.Random.value);
                }
            }
        }

        public void SetActivityVisible(bool visible)
        {
            AndroidInterface.SetActivityVisible(visible);
        }

        public void Quit()
        {
            XRManager.Instance.Quit();
        }


        private static long CurrentTimeStamp()
        {
            var ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            long times = Convert.ToInt64(ts.TotalMilliseconds);
            return times;
        }
        public void InjectKey(bool down)
        {
            var eventTime = CurrentTimeStamp();
            XRMotionEvent ev = new XRMotionEvent();
            ev.action = down ? XRMotionEventAction.XR_MOTION_EVENT_ACTION_DOWN : XRMotionEventAction.XR_MOTION_EVENT_ACTION_UP;
            ev.deviceId = XRInputDeviceID.XR_INPUT_DEVICE_ID_CONTROLLER0;
            ev.metaState = 0;
            ev.downTime = eventTime;
            ev.eventTime = eventTime;

            ev.pointerCount = 1;
            ///确保id不会和Unity本身的fingerID重复
            ev.pointerProperties = new XRPointerProperties[] { new XRPointerProperties() { id = 100 } };

            ev.pointerCoords = new XRPointerCoords[] { new XRPointerCoords() { x = 0, y = 0, deltaX = 0, deltaY = 0 } };

            InputManager.Inject(ev);
        }
    }
}