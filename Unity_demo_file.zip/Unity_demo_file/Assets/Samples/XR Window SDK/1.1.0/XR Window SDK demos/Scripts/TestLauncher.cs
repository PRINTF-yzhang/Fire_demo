﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace XR.Samples
{
    public class TestLauncher : MonoBehaviour
    {
        protected struct AppButton
        {
            public Package package;
            public Button button;
        }
        public static event Action OnOpenApp;
        public Vector2 offset;
        public int packageRow;
        public int packageColumn;
        public int runningAppRow;
        public int runningAppColumn;
        public GameObject packagePrefab;
        public GameObject runningAppPrefab;
        private List<Button> packageButtons = new List<Button>();
        private List<Button> runningAppButtons = new List<Button>();
        private Dictionary<string, Package> packageDictionary = new Dictionary<string, Package>();

        public GameObject installationPrefab;
        protected struct InstallationBoard
        {
            public GameObject root;
            public TMP_Text package;
            public TMP_Text progress;
        }
        private Dictionary<string, InstallationBoard> installationDic = new Dictionary<string, InstallationBoard>();
        protected virtual void Start()
        {
            GenerateButtons(packagePrefab, packageButtons, packageRow, packageColumn);
            GenerateButtons(runningAppPrefab, runningAppButtons, runningAppRow, runningAppColumn);
            if (XRManager.Initialized)
            {
                AppManager.OnAppStatus += OnAppStatus;
                PackageManager.OnPackageEvent += OnPackageEvent;
                PackageManager.OnPackageInstallEvent += OnPackageInstallEvent;

                RefreshPackageButtons();
                RefreshRunningAppButtons();
            }
        }

        protected virtual void OnDestroy()
        {
            if (XRManager.Initialized)
            {
                AppManager.OnAppStatus -= OnAppStatus;
                PackageManager.OnPackageEvent -= OnPackageEvent;
                PackageManager.OnPackageInstallEvent -= OnPackageInstallEvent;
            }
        }

        private void OnAppStatus(string packageName, XRAppStatus status)
        {
            RefreshRunningAppButtons();
        }

        private void OnPackageInstallEvent(XRPackageInstallEvent type, string packageName, int value)
        {
            InstallationBoard board;
            if (type == XRPackageInstallEvent.XR_PACKAGE_INSTALL_EVENT_START)
            {
                GameObject root = Instantiate(installationPrefab, installationPrefab.transform.parent, true);
                root.SetActive(true);
                board = new InstallationBoard() { root = root, package = root.transform.GetChild(0).GetComponent<TMP_Text>(), progress = root.transform.GetChild(1).GetComponent<TMP_Text>() };
                board.package.text = $"Installing {packageName}";
                board.progress.text = "";
                installationDic.Add(packageName, board);
            }
            else
            {
                installationDic.TryGetValue(packageName, out board);
                if (type == XRPackageInstallEvent.XR_PACKAGE_INSTALL_EVENT_FINISH)
                {
                    board.package.text = $"Installed {packageName}";
                    board.progress.text = "";
                    StartCoroutine(InstallFinishCoroutine(board));
                }
                else if (type == XRPackageInstallEvent.XR_PACKAGE_INSTALL_EVENT_PROGRESS_UPDATE)
                {
                    board.package.text = $"Installing {packageName}";
                    board.progress.text = $"{value}%";
                }
            }
        }

        IEnumerator InstallFinishCoroutine(InstallationBoard board)
        {
            yield return new WaitForSeconds(3.0f);
            board.root.SetActive(false);
            Destroy(board.root);
        }

        private void GenerateButtons(GameObject prefab, List<Button> buttons, int row, int column)
        {
            for (int i = 0; i < row; ++i)
            {
                for (int j = 0; j < column; ++j)
                {
                    Button button = Instantiate(prefab, prefab.transform.parent, true).GetComponent<Button>();
                    button.transform.localPosition += new Vector3(offset.x * j, offset.y * i);
                    button.gameObject.SetActive(true);
                    buttons.Add(button);
                }
            }
        }

        private void OnPackageEvent(XRPackageEvent ev, Package package)
        {
            switch (ev)
            {
                case XRPackageEvent.XR_PACKAGE_EVENT_ADD:
                case XRPackageEvent.XR_PACKAGE_EVENT_REMOVE:
                case XRPackageEvent.XR_PACKAGE_EVENT_UPDATE:
                    RefreshPackageButtons();
                    break;
                default:
                    Debug.LogErrorFormat("OnPackageEvent received invalid parameter: {0}", ev);
                    break;
            }
        }

        private void RefreshPackageButtons()
        {
            var list = PackageManager.GetPackageList();

            if (list == null)
            {
                list = new List<Package>();
            }
            packageDictionary.Clear();
            foreach (var package in list)
            {
                Debug.Log($"Found package {package.Name}, Description: {package.Description}, Mode: {package.Mode}, Type: {package.Type}\n"
                    + $"Version: {package.Version}, Visible: {package.Visible}, Persist: {package.Persist}\n"
                    + $"Default Icon: {package.DefaultIcon}, Preview Icon: {package.PreviewIcon}, Running Icon: {package.RunningIcon}\n"
                    + $"Foreground Icon: {package.ForegroundIcon}, Background Icon: {package.BackgroundIcon}");
                packageDictionary.Add(package.Name, package);
            }
            for (var i = 0; i < packageButtons.Count; ++i)
            {
                var button = packageButtons[i];
                if (i >= list.Count)
                {
                    button.gameObject.SetActive(false);
                }
                else
                {
                    button.gameObject.SetActive(true);
                    button.GetComponentInChildren<TMP_Text>().text = list[i].Description;
                    button.onClick.RemoveAllListeners();
                    string packageName = list[i].Name;
                    button.onClick.AddListener(() =>
                    {
                        StartApp(packageName);
                    });
                }
            }
        }

        private void RefreshRunningAppButtons()
        {
            var list = AppManager.GetRunningAppList();

            if (list == null)
            {
                foreach (var button in runningAppButtons)
                {
                    button.gameObject.SetActive(false);
                }
            }
            else
            {
                Button button;
                for (var i = 0; i < runningAppButtons.Count; ++i)
                {
                    button = runningAppButtons[i];
                    if (i >= list.Length)
                    {
                        button.gameObject.SetActive(false);
                    }
                    else
                    {
                        button.gameObject.SetActive(true);
                        string desc = null;
                        Package package = null;
                        if (packageDictionary.TryGetValue(list[i].Name, out package))
                        {
                            desc = package.Description;
                        }
                        else
                        {
                            desc = list[i].Name;
                        }
                        button.GetComponentInChildren<TMP_Text>().text = desc;
                    }
                }
            }
        }

        public void StartApp(string packageName)
        {
            AppManager.StartApp(packageName);
            OnOpenApp?.Invoke();
        }
    }
}