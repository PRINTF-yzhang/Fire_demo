﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace XR.Samples
{
    public class TestCamera : MonoBehaviour
    {
        public int targetWidth = 1920;
        public int targetHeight = 1080;
        public RawImage image;
        public bool openAnyway = true;

        CameraDevice device = null;
        Texture2D texture = null;
        bool opened = false;
        public void OpenCamera()
        {
            CloseCamera();
            var cameraList = CameraDevice.GetCameraList();
            if (cameraList == null)
            {
                Debug.LogError("GetCameraList fail");
                return;
            }
            XRCameraConfig targetConfig = new XRCameraConfig();
            CameraDevice targetCamera = null;
            for (int i = 0; i < cameraList.Length; ++i)
            {
                StringBuilder b = new StringBuilder();
                b.AppendLine(string.Format("Camera Device [{0}]", i));
                b.AppendFormat("Supported configs:");
                if (cameraList[i].SupportedConfigs != null)
                {
                    foreach (var config in cameraList[i].SupportedConfigs)
                    {
                        b.AppendFormat(" [Format:{0} Size:{1}x{2} FPS:{3}]", config.format, config.width, config.height, config.maxFps);
                        if (config.width == targetWidth && config.height == targetHeight)
                        {
                            targetConfig = config;
                            targetCamera = cameraList[i];
                            break;
                        }
                    }
                }
                Debug.Log(b.ToString());
            }
            if (targetCamera == null)
            {
                Debug.LogErrorFormat("Could not find config with width:{0} height:{1}", targetWidth, targetHeight);
                //若设置了open anyway，则使用第一个相机的第一个配置
                if (openAnyway && cameraList != null && cameraList.Length > 0)
                {
                    targetCamera = cameraList[0];
                    if (targetCamera.SupportedConfigs.Length > 0)
                    {
                        targetConfig = targetCamera.SupportedConfigs[0];
                        Debug.LogErrorFormat("Use config with width:{0} height:{1} by default.", targetConfig.width, targetConfig.height);
                    }
                    else return;
                }
                else return;
            }

            CameraParameter param = null;
            var error = targetCamera.GetParameter(out param);
            if (error == XRError.XR_ERROR_SUCCESS)
            {
                const string paramKey = "height";
                Debug.LogFormat("Camera parameter support [{0}: {1}]", paramKey, param.IsParameterSupported(paramKey));
                Debug.LogFormat("Camera parameter value before [{0}: {1}]", paramKey, param[paramKey]);
                param[paramKey] = "1920";
                Debug.LogFormat("Camera parameter value after [{0}: {1}]", paramKey, param[paramKey]);

                error = targetCamera.SetParameter(param);
                if (error == XRError.XR_ERROR_SUCCESS)
                {
                    targetCamera.GetParameter(out param);
                    Debug.LogFormat("Camera parameter value after set [{0}: {1}]", paramKey, param[paramKey]);
                }
                else
                {
                    Debug.LogErrorFormat("Set camera parameter failed: {0}", error);
                }
            }
            else
            {
                Debug.LogErrorFormat("Get camera parameter failed: {0}", error);
            }

            XRMatrix4f projection = new XRMatrix4f();
            XRPose pose = new XRPose();
            error = targetCamera.GetCalibrationData(targetConfig, ref projection, ref pose);
            if (error == XRError.XR_ERROR_SUCCESS)
            {
                Debug.LogFormat("Camera calibration data: pose:{0} projection:{1}", pose, projection);
            }
            else
            {
                Debug.LogError("Get camera calibration data fail: " + error);
            }

            error = targetCamera.Open(targetConfig);
            if (error == XRError.XR_ERROR_SUCCESS)
            {
                Debug.Log("Open camera succeed!");
                device = targetCamera;
                texture = new Texture2D(targetConfig.width, targetConfig.height, TextureFormat.RGB24, false);
                if (image != null)
                {
                    image.texture = texture;
                }
                opened = true;
                return;
            }
            else
            {
                Debug.LogError("Open camera fail: " + error);
            }

            device = null;
            texture = null;
            image.texture = null;
            opened = false;
        }
        public void CloseCamera()
        {
            if (opened)
            {
                device.Close();
                device = null;
                texture = null;
                image.texture = null;
                opened = false;
            }
        }
        private void Update()
        {
            if (opened)
            {
                using (var image = device.GetOneShotPreview())
                {
                    if (image == null)
                    {
                        return;
                    }
                    Debug.LogFormat("GetOneShotPreview {0} {1} {2}x{3}", image.SourceType, image.PixelFormat, image.Width, image.Height);
                    var error = LibYuv.Convert(texture, image.Width, image.Height, image.DataPointer);
                    if (error != 0)
                    {
                        Debug.LogError("LibYuv convert fail: " + error);
                    }
                }
            }
        }
    }
}