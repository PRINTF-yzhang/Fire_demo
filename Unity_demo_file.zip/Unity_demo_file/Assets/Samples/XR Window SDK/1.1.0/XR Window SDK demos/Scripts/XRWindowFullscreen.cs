﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using UnityEngine;

namespace XR.Samples
{
    public class XRWindowFullscreen : XRWindowBase
    {
        public Transform cursor;
        bool usingController = false;

        /// <summary>
        /// 使用自定义射线<para>Use custom cursor line</para>
        /// </summary>
        /// <returns></returns>
        public override bool HasCursor()
        {
            return true;
        }
        public override XRRayCastInfo OnRay(XRRay ray, XRFocusState focusState)
        {
            var info = base.OnRay(ray, focusState);
            cursor.position = ray.pose.position.ToVector3_FlipZ();
            cursor.forward = ray.direction.ToVector3_FlipZ();
            var scale = cursor.localScale;
            scale.z = info.rayLength;
            cursor.localScale = scale;
            return info;
        }

        public override void OnFullscreen(bool fullscreen)
        {
            base.OnFullscreen(fullscreen);
            CameraClearFlags flag = fullscreen ? CameraClearFlags.Skybox : CameraClearFlags.SolidColor;
            XRCameraManager.Instance.stereoCamera.GetComponent<Camera>().clearFlags = flag;
            UpdateControllerStatus();
        }

        public override void Create()
        {
            base.Create();
            WindowFullscreen = true;
        }

        public override void OnInputDeviceChanged(XRInputDeviceID deviceId)
        {
            base.OnInputDeviceChanged(deviceId);
            switch (deviceId)
            {
                case XRInputDeviceID.XR_INPUT_DEVICE_ID_CONTROLLER0:
                case XRInputDeviceID.XR_INPUT_DEVICE_ID_CONTROLLER1:
                    usingController = true;
                    break;
                default:
                    usingController = false;
                    break;
            }
            UpdateControllerStatus();
        }

        void UpdateControllerStatus()
        {
            cursor.gameObject.SetActive(usingController && WindowFullscreen);
        }

        public void ButtonSetWindowFullscreen()
        {
            if (Initialzed)
            {
                WindowFullscreen = !WindowFullscreen;
            }
        }

    }
}