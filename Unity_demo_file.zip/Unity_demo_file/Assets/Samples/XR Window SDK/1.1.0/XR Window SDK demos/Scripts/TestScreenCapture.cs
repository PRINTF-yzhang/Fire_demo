﻿/*
** Copyright(C) IrisView Limited
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
using System;
using System.IO;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.UI;

namespace XR.Samples
{
    public class TestScreenCapture : MonoBehaviour
    {
        public RawImage rawImage;
        private Texture2D texture;
        private void Awake()
        {
            var size = ScreenCapture.ScreenSize;
            texture = new Texture2D((int)size.width, (int)size.height, TextureFormat.RGBA32, false);
            rawImage.texture = texture;
            if (XRManager.Initialized)
            {
                ScreenCapture.OnScreenCaptureResult += ScreenCapture_OnScreenCaptureResult;
                ScreenCapture.OnScreenCaptureModeChange += ScreenCapture_OnScreenCaptureModeChange;
                ScreenCapture.OnScreenShotData += ScreenCapture_OnScreenShotData;
                if (!Directory.Exists("/sdcard/test_screencapture"))
                {
                    Directory.CreateDirectory("/sdcard/test_screencapture");
                }
            }
        }

        private void OnDestroy()
        {
            if (XRManager.Initialized)
            {
                ScreenCapture.OnScreenCaptureResult += ScreenCapture_OnScreenCaptureResult;
                ScreenCapture.OnScreenCaptureModeChange += ScreenCapture_OnScreenCaptureModeChange;
                ScreenCapture.OnScreenShotData += ScreenCapture_OnScreenShotData;
            }
        }

        private void ScreenCapture_OnScreenShotData(long identifier, BufferImage image)
        {
            Debug.LogFormat("OnScreenShotData: {0} {1}x{2}", identifier, image.Width, image.Height);
            var buffer = texture.GetRawTextureData<byte>();
            unsafe
            {
                Buffer.MemoryCopy(image.DataPointer.ToPointer(), buffer.GetUnsafePtr(), buffer.Length, image.Width * image.Height * 4);
            }
            texture.Apply();
        }

        private void ScreenCapture_OnScreenCaptureModeChange(XRScreenCaptureMode mode, bool enable)
        {
            Debug.LogFormat("OnScreenCaptureModeChange: {0} {1}", mode, enable);
        }

        private void ScreenCapture_OnScreenCaptureResult(XRScreenCaptureEventType type, long identifier, XRError error)
        {
            Debug.LogFormat("OnScreenCaptureResult: {0} {1} {2}", type, identifier, error);
        }

        public void SaveScreen()
        {
            XRScreenCaptureOptions options = XRScreenCaptureOptions.Default;
            options.flags = (ulong)XRScreenCaptureFlag.XR_SCREEN_CAPTURE_FLAG_MIXREALITY;
            XRScreenCaptureExtraOptions extraOptions = XRScreenCaptureExtraOptions.Default;
            extraOptions.cameraWidth = 2560;
            extraOptions.cameraHeight = 1440;
            ScreenCapture.ScreenShot(options, "/sdcard/test_screencapture/ScreenShot.png", extraOptions);
        }
        public void BeginCapture()
        {
            XRScreenCaptureOptions options = XRScreenCaptureOptions.Default;
            options.flags = (ulong)XRScreenCaptureFlag.XR_SCREEN_CAPTURE_FLAG_MIXREALITY;
            XRScreenCaptureStreamOptions streamOptions = XRScreenCaptureStreamOptions.Default;
            streamOptions.audioSource = XRScreenCaptureAudioSource.XR_SCREEN_CAPTURE_AUDIO_SOURCE_MIC;
            streamOptions.bitrate = 10000;
            ScreenCapture.StartCapture(options, XRScreenCaptureMode.XR_SCREEN_CAPTURE_MODE_CAPTURE, "/sdcard/test_screencapture/ScreenCapture.mp4", streamOptions, XRScreenCaptureExtraOptions.Default);
        }
        public void EndCapture()
        {
            ScreenCapture.EndCapture();
        }
    }
}